God Sword 3D + Красный мейс — Minecraft Java 1.21.11 (vanilla, no mods needed)

Золотой меч: переименуй в Меч Бога (также работает с градиентным названием).
Мейс: переименуй в Мейс Дьявола или Булава демона (красный градиент),
либо выдай мейс с компонентом item_model="minecraft:devil_mace":
/give @s minecraft:mace[item_model="minecraft:devil_mace"]
